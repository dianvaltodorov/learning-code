To compile the program:
gcc hw2_61670.c -lpcap;

To run the binary:
./a.out

Then input the name of the file (e.g. h2w.pcap)
